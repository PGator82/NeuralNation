import { RoyaltyPayment } from '../generated/schema'
import { Paid } from '../generated/RoyaltyRouter/Royalty'

export function handlePaid(event: Paid): void {
  let id = event.transaction.hash.toHex() + "-" + event.logIndex.toString()
  let r = new RoyaltyPayment(id)
  r.payer = event.params.payer
  r.token = event.params.token
  r.amount = event.params.amount
  // NFT address & tokenId could be added to event in future; leaving generic for now
  r.nft = event.address
  r.tokenId = BigInt.zero()
  r.timestamp = event.block.timestamp
  r.save()
}
