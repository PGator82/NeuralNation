#!/usr/bin/env python3
import os, json, time, hashlib, requests
EVE_FILE = os.environ.get("EVE_FILE","/var/log/suricata/eve.json")
ORACLE_WEBHOOK = os.environ.get("ORACLE_WEBHOOK","http://localhost:8787/alert")
def tail(f):
  f.seek(0,2)
  while True:
    line=f.readline()
    if not line: time.sleep(0.5); continue
    yield line
def main():
  with open(EVE_FILE,"r") as f:
    for line in tail(f):
      try: evt=json.loads(line)
      except: continue
      if evt.get("event_type")!="alert": continue
      fp = hashlib.sha256(json.dumps(evt, sort_keys=True).encode()).hexdigest()
      sev = evt.get("alert",{}).get("severity",2)
      body={"fingerprint":fp,"severity":sev,"timestamp":int(time.time())}
      try: requests.post(ORACLE_WEBHOOK, json=body, timeout=2)
      except: pass
if __name__=="__main__": main()
