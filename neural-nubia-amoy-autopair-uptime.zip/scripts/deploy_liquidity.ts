// scripts/deploy_liquidity.ts
// Skeleton for QuickSwap (UniswapV2) on Polygon
// You must set FACTORY, ROUTER, USDC addresses for Amoy/mainnet as needed.
import { ethers } from "hardhat";

const FACTORY = process.env.QS_FACTORY as string || "0x5757371414417b8c6caad45baef941abc7d3ab32"; // QuickSwap V2 (Polygon mainnet)
const ROUTER  = process.env.QS_ROUTER  as string || "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"; // QuickSwap V2 router
const USDC    = process.env.USDC as string || "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"; // USDC (Polygon)
const NNC     = process.env.NNC as string || ""; // set deployed NNC

const ABI_FACTORY = [{"name":"createPair","type":"function","inputs":[{"name":"tokenA","type":"address"},{"name":"tokenB","type":"address"}],"outputs":[{"type":"address"}],"stateMutability":"nonpayable"}]
const ABI_ROUTER = [
  {"name":"addLiquidity","type":"function","stateMutability":"nonpayable","inputs":[
    {"name":"tokenA","type":"address"},{"name":"tokenB","type":"address"},
    {"name":"amountADesired","type":"uint256"},{"name":"amountBDesired","type":"uint256"},
    {"name":"amountAMin","type":"uint256"},{"name":"amountBMin","type":"uint256"},
    {"name":"to","type":"address"},{"name":"deadline","type":"uint256"}],"outputs":[
    {"type":"uint256"},{"type":"uint256"},{"type":"uint256"}]}
]

async function main(){
  const [deployer] = await ethers.getSigners();
  if(!NNC) throw new Error("Set NNC env var to your token address");
  console.log("Deployer:", deployer.address);

  const factory = new ethers.Contract(FACTORY, ABI_FACTORY, deployer);
  const router  = new ethers.Contract(ROUTER, ABI_ROUTER, deployer);

  const amountNNC = ethers.parseUnits(process.env.SEED_NNC || "1000000", 18);   // 1,000,000 NNC
  const amountUSDC = ethers.parseUnits(process.env.SEED_USDC || "100000", 6);   // 100,000 USDC (0.10 each)

  // Approvals required beforehand
  console.log("Approve NNC and USDC to router before running this script.");

  const deadline = Math.floor(Date.now()/1000) + 3600;
  const tx = await router.addLiquidity(
    NNC, USDC,
    amountNNC, amountUSDC,
    amountNNC * 99n/100n, amountUSDC * 99n/100n,
    deployer.address,
    deadline
  );
  const rc = await tx.wait();
  console.log("Liquidity added. Receipt:", rc?.hash);
}

main().catch(e=>{ console.error(e); process.exit(1); });
