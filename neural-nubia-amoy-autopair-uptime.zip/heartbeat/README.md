# Neural Nubia — Node Heartbeat

- `agent.py` (runs on citizen node, sends a beat every 60s)
- `server.js` (Express API that collects beats and exposes `/nodes`)

## Run API
```bash
cd heartbeat
npm install
node server.js
# GET http://localhost:8788/nodes
```

## Run Agent
```bash
export NN_HEARTBEAT_URL=http://<server>:8788/beat
export NN_WALLET=0xYourWallet
python3 heartbeat/agent.py &
```
