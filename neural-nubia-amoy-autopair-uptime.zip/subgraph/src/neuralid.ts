import { NetworkStats } from '../generated/schema'
import { Transfer } from '../generated/NeuralID/NeuralID'
import { BigInt, Address } from '@graphprotocol/graph-ts'

export function handleNidTransfer(event: Transfer): void {
  // Count only mints (from == 0x0)
  if (event.params.from.toHex() != '0x0000000000000000000000000000000000000000') return
  let s = NetworkStats.load("global")
  if (s == null) { s = new NetworkStats("global"); s.tvl = BigInt.zero(); s.citizens = BigInt.zero(); s.royalties30d = BigInt.zero(); s.alerts = BigInt.zero(); }
  s.citizens = s.citizens.plus(BigInt.fromI32(1))
  s.save()
}
