import { RoyaltyPayment, NetworkStats } from '../generated/schema'
 '../generated/schema'
import { Paid } from '../generated/RoyaltyRouter/Royalty'

export function handlePaid(event: Paid): void {
  let id = event.transaction.hash.toHex() + "-" + event.logIndex.toString()
  let r = new RoyaltyPayment(id)
  r.payer = event.params.payer
  r.token = event.params.token
  r.amount = event.params.amount
  // NFT address & tokenId could be added to event in future; leaving generic for now
  r.nft = event.address
  r.tokenId = BigInt.zero()
  r.timestamp = event.block.timestamp
  r.save()
  let stats = loadStats(); stats.royalties30d = stats.royalties30d.plus(event.params.amount); stats.save()
}


function loadStats(): NetworkStats {
  let s = NetworkStats.load("global")
  if (s == null) { s = new NetworkStats("global"); s.tvl = BigInt.zero(); s.citizens = BigInt.zero(); s.royalties30d = BigInt.zero(); s.alerts = BigInt.zero(); }
  return s as NetworkStats
}
