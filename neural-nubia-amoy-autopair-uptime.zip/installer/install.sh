#!/usr/bin/env bash
set -euo pipefail
echo "==> Neural Nubia Citizen Node Installer (Polygon + IPFS)"
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is required. Please install Docker and re-run."
  exit 1
fi
if ! command -v docker compose >/dev/null 2>&1; then
  echo "Docker Compose plugin is required. Install docker-compose-plugin."
  exit 1
fi

mkdir -p nnn/data/ipfs nnn/data/polygon nnn/dashboard
cat > nnn/.env <<EOF
RPC_UPSTREAM=https://rpc-amoy.polygon.technology
IPFS_PROFILE=server
EOF

cat > nnn/docker-compose.yml <<'YAML'
version: "3.8"
services:
  polygon:
    image: ghcr.io/umbracle/erpc:latest
    container_name: nn_polygon_light
    restart: unless-stopped
    environment:
      - UPSTREAM=${RPC_UPSTREAM}
    ports:
      - "8545:8545"
    command: ["--upstream", "${RPC_UPSTREAM}", "--listen", "0.0.0.0:8545"]
    volumes:
      - ./data/polygon:/data

  ipfs:
    image: ipfs/kubo:latest
    container_name: nn_ipfs
    restart: unless-stopped
    ports:
      - "4001:4001/tcp"
      - "5001:5001/tcp"
      - "8080:8080/tcp"
    environment:
      IPFS_PROFILE: ${IPFS_PROFILE}
    volumes:
      - ./data/ipfs:/data/ipfs

  dashboard:
    image: nginx:alpine
    container_name: nn_dashboard
    restart: unless-stopped
    ports:
      - "8090:80"
    volumes:
      - ./dashboard:/usr/share/nginx/html:ro
YAML

# simple local status page
cat > nnn/dashboard/index.html <<'HTML'
<!doctype html>
<html><head><meta charset="utf-8"><title>Neural Nubia — Citizen Node</title>
<style>body{font-family:system-ui;background:#0b0b0b;color:#f3f3f3;margin:2rem} a{color:#facc15}</style></head>
<body>
<h1>Neural Nubia — Citizen Node</h1>
<ul>
  <li>Polygon RPC (local): <a href="http://localhost:8545" target="_blank">http://localhost:8545</a></li>
  <li>IPFS Gateway: <a href="http://localhost:8080" target="_blank">http://localhost:8080</a></li>
  <li>IPFS API: <a href="http://localhost:5001/webui" target="_blank">http://localhost:5001/webui</a></li>
</ul>
<p>Keep this device online to earn staking + service rewards.</p>
</body></html>
HTML

echo "==> Starting services (polygon light, ipfs, dashboard)"
cd nnn
docker compose up -d
echo "==> Done. Open http://localhost:8090 for the local dashboard."
