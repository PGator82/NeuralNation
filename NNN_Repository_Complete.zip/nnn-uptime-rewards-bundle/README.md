
# Neural Nubia — Uptime Rewards

## Contract
- `UptimeRewards.sol`
  - Owner sets `oracle` and `weeklyBudget`
  - Fund with NNC via `fund(amount)`
  - Oracle calls `report(address[], uint16[] uptimeBips, start, end)` to distribute budget as claimable balances
  - Citizens call `claim()` to pull rewards

## Oracle Updater
- `scripts/uptime_report.ts`
  - Reads `{HEARTBEAT_URL}/nodes`
  - Uses online nodes' `uptimePct` to weight distribution
  - Calls `report()` with the week window

### ENV for updater
```
RPC=https://rpc-amoy.polygon.technology
ORACLE_KEY=0xYOUR_PRIVATE_KEY
UPTIME=0xDeployedUptimeRewards
HEARTBEAT_URL=http://localhost:8788
WEEKLY_BUDGET=10000
```

## Frontend
- `/uptime` page shows pending rewards & claim button
- Reads nodes list from `NEXT_PUBLIC_HEARTBEAT_URL`

### Frontend ENV
```
NEXT_PUBLIC_UPTIME_ADDRESS=0xDeployedUptimeRewards
NEXT_PUBLIC_HEARTBEAT_URL=http://localhost:8788
```

## Deploy steps
1. Deploy `UptimeRewards` with NNC address, oracle wallet, and starting budget
2. Fund with NNC (owner `approve` then `fund(amount)`)
3. Run `uptime_report.ts` weekly (cron) or on demand
4. Citizens visit `/uptime` to claim

