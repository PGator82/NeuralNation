import { Stake } from '../generated/schema'
import { Staked, Unstaked } from '../generated/NNCStaking/Staking'

export function handleStaked(event: Staked): void {
  let id = event.params.user.toHex()
  let s = Stake.load(id)
  if (s == null) { s = new Stake(id); s.user = event.params.user; s.amount = BigInt.zero() }
  s.amount = s.amount.plus(event.params.amount)
  s.updatedAt = event.block.timestamp
  s.save()
}

export function handleUnstaked(event: Unstaked): void {
  let id = event.params.user.toHex()
  let s = Stake.load(id)
  if (s == null) { s = new Stake(id); s.user = event.params.user; s.amount = BigInt.zero() }
  s.amount = s.amount.minus(event.params.amount)
  s.updatedAt = event.block.timestamp
  s.save()
}
