// heartbeat/server.js
// Minimal API to collect node heartbeats (in-memory) and expose for dashboard
const express = require('express')
const app = express()
app.use(express.json())

const nodes = new Map() // nodeId -> { wallet, ts }
app.post('/beat', (req, res) => {
  const { nodeId, wallet, ts } = req.body || {}
  if(!nodeId || !wallet || !ts) return res.status(400).json({ ok:false })
  nodes.set(nodeId, { wallet, ts })
  return res.json({ ok: true })
})

app.get('/nodes', (req, res) => {
  const now = Math.floor(Date.now()/1000)
  const out = []
  for (const [nodeId, info] of nodes.entries()){
    out.push({ nodeId, wallet: info.wallet, ts: info.ts, online: (now - info.ts) <= 300 })
  }
  res.json({ nodes: out })
})

const PORT = process.env.PORT || 8788
app.listen(PORT, () => console.log('Heartbeat API on :' + PORT))
