import Link from 'next/link'
export default function Home(){
  return (<main style={{maxWidth:800,margin:'2rem auto',padding:'0 1rem'}}>
    <h1>Neural Nubia Network</h1>
    <p>From the Old Kingdom to the New Code.</p>
    <div className="card"><h2>Start Here</h2><ul>
      <li><a href="/onboard">Claim Starter NNC (Onboard)</a></li>
      <li><Link href="/passport">Mint your <b>Neural ID</b></Link></li>
      <li><Link href="/stake">Stake NNC</Link></li>
      <li><Link href="/vault">Creator Vault (mint & royalties)</Link></li>
      <li><Link href="/security">Cybersecurity Node</Link></li>
          <li><a href="/dashboard">Network Dashboard (Subgraph)</a></li>
    </ul></div>
    <div className="card">
      <h2>NNC Price</h2>
      <p>Coming soon: live price from QuickSwap pool.</p>
      <a href="https://quickswap.exchange" target="_blank" rel="noreferrer">Swap on QuickSwap</a>
    </div>
    
</main>)
}
