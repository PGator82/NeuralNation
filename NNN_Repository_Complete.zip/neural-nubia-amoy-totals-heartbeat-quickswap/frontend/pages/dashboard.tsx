import { useEffect, useState } from 'react'
import { gql } from '@/lib/subgraph'

type Proposal = { id: string, description: string, state: string, votesFor: string, votesAgainst: string, votesAbstain: string, createdAt: string }
type Stake = { id: string, amount: string }
type SecurityAlert = { id: string, reporter: string, severity: number, timestamp: string, bountyPaid: boolean }

export default function Dashboard(){
  const [proposals, setProposals] = useState<Proposal[]>([])
  const [stakes, setStakes] = useState<Stake[]>([])
  const [alerts, setAlerts] = useState<SecurityAlert[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string|undefined>()

  useEffect(()=>{
    (async ()=>{
      try{
        const data = await gql(`
          {
            proposals(first: 10, orderBy: createdAt, orderDirection: desc){
              id description state votesFor votesAgainst votesAbstain createdAt
            }
            stakes(first: 10, orderBy: updatedAt, orderDirection: desc){
              id amount
            }
            securityAlerts(first: 10, orderBy: timestamp, orderDirection: desc){
              id reporter severity timestamp bountyPaid
            }
          }
        `)
        setProposals(data.proposals||[])
        setStakes(data.stakes||[])
        setAlerts(data.securityAlerts||[])
      }catch(e:any){
        setError(e?.message || "Failed to load subgraph")
      }finally{
        setLoading(false)
      }
    })()
  }, [])

  return (
    <main style={{maxWidth:1000,margin:'2rem auto',padding:'0 1rem'}}>
      <h1>Neural Nubia — Network Dashboard</h1>

      <div className="card" style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'12px'}}>
        <div><div style={{opacity:.7}}>TVL (Staking)</div><div style={{fontSize:'1.4rem'}}>{/* TODO: subgraph sum */}Coming Soon</div></div>
        <div><div style={{opacity:.7}}>Active Citizens</div><div style={{fontSize:'1.4rem'}}>Coming Soon</div></div>
        <div><div style={{opacity:.7}}>Monthly Royalties</div><div style={{fontSize:'1.4rem'}}>Coming Soon</div></div>
        <div><div style={{opacity:.7}}>Active Nodes</div><div style={{fontSize:'1.4rem'}}>Coming Soon</div></div>
      </div>
    
      {!loading && error && <div className="card"><b>Error:</b> {error}</div>}
      {loading && <div className="card">Loading...</div>}

      <div className="card">
        <h2>Latest Proposals</h2>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th align="left">ID</th><th align="left">State</th><th align="left">Votes (For/Against/Abstain)</th><th align="left">Description</th></tr></thead>
          <tbody>
            {proposals.map(p=>(
              <tr key={p.id}><td>{p.id}</td><td>{p.state}</td><td>{p.votesFor}/{p.votesAgainst}/{p.votesAbstain}</td><td>{p.description}</td></tr>
            ))}
            {proposals.length===0 && <tr><td colSpan={4} style={{opacity:.7}}>No proposals yet.</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2>Recent Staking Activity</h2>
        <ul>
          {stakes.map(s=>(<li key={s.id}><b>User:</b> {s.id} — <b>Staked:</b> {s.amount}</li>))}
          {stakes.length===0 && <li style={{opacity:.7}}>No staking events yet.</li>}
        </ul>
      </div>

      <div className="card">
        <h2>Security Alerts</h2>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th align="left">Fingerprint</th><th align="left">Reporter</th><th align="left">Severity</th><th align="left">Bounty</th></tr></thead>
          <tbody>
            {alerts.map(a=>(
              <tr key={a.id}><td style={{fontFamily:'monospace'}}>{a.id.slice(0,10)}…</td><td>{a.reporter}</td><td>{a.severity}</td><td>{a.bountyPaid ? 'Paid' : 'Pending'}</td></tr>
            ))}
            {alerts.length===0 && <tr><td colSpan={4} style={{opacity:.7}}>No alerts yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </main>
  )
}
