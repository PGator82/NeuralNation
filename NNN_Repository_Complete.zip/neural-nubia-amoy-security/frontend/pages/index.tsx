import Link from 'next/link'
export default function Home(){
  return (<main style={{maxWidth:800,margin:'2rem auto',padding:'0 1rem'}}>
    <h1>Neural Nubia Network</h1>
    <p>From the Old Kingdom to the New Code.</p>
    <div className="card"><h2>Start Here</h2><ul>
      <li><Link href="/passport">Mint your <b>Neural ID</b></Link></li>
      <li><Link href="/stake">Stake NNC</Link></li>
      <li><Link href="/vault">Creator Vault (mint & royalties)</Link></li>
      <li><Link href="/security">Cybersecurity Node</Link></li>
    </ul></div></main>)
}
