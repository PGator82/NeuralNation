import { Stake, NetworkStats } from '../generated/schema'
 '../generated/schema'
import { Staked, Unstaked } from '../generated/NNCStaking/Staking'

export function handleStaked(event: Staked): void {
  let id = event.params.user.toHex()
  let s = Stake.load(id)
  if (s == null) { s = new Stake(id); s.user = event.params.user; s.amount = BigInt.zero() }
  s.amount = s.amount.plus(event.params.amount)
  s.updatedAt = event.block.timestamp
  s.save()
  let stats = loadStats(); stats.tvl = stats.tvl.plus(event.params.amount); stats.save()
  let stats2 = loadStats(); stats2.tvl = stats2.tvl.minus(event.params.amount); stats2.save()
}

export function handleUnstaked(event: Unstaked): void {
  let id = event.params.user.toHex()
  let s = Stake.load(id)
  if (s == null) { s = new Stake(id); s.user = event.params.user; s.amount = BigInt.zero() }
  s.amount = s.amount.minus(event.params.amount)
  s.updatedAt = event.block.timestamp
  s.save()
  let stats = loadStats(); stats.tvl = stats.tvl.plus(event.params.amount); stats.save()
  let stats2 = loadStats(); stats2.tvl = stats2.tvl.minus(event.params.amount); stats2.save()
}


function loadStats(): NetworkStats {
  let s = NetworkStats.load("global")
  if (s == null) { s = new NetworkStats("global"); s.tvl = BigInt.zero(); s.citizens = BigInt.zero(); s.royalties30d = BigInt.zero(); s.alerts = BigInt.zero(); }
  return s as NetworkStats
}
