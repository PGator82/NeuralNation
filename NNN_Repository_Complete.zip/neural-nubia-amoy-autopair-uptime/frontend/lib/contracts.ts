export const ADDRS = { NNC: process.env.NEXT_PUBLIC_NNC_ADDRESS || "", NEURAL_ID: process.env.NEXT_PUBLIC_NEURALID_ADDRESS || "" };
export const ADDR_MORE = { CNFT: process.env.NEXT_PUBLIC_CNFT_ADDRESS || "", ROYALTY: process.env.NEXT_PUBLIC_ROYALTY_ADDRESS || "" };
export const ABI_NNC = [
  {"inputs":[{"internalType":"address","name":"treasury","type":"address"},{"internalType":"uint256","name":"initialSupply","type":"uint256"}], "stateMutability":"nonpayable","type":"constructor"},
  {"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"}
];
export const ABI_NeuralID = [
  {"inputs":[{"internalType":"address","name":"who","type":"address"},{"internalType":"bool","name":"ok","type":"bool"}],"name":"setIssuer","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"bytes32","name":"hash","type":"bytes32"}],"name":"mint","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[],"name":"nextId","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}
];
export const ABI_CNFT = [
  {"type":"function","name":"mint","stateMutability":"nonpayable","inputs":[{"name":"to","type":"address"},{"name":"uri","type":"string"}],"outputs":[{"type":"uint256"}]}
];
export const ABI_Royalty = [
  {"type":"function","name":"setSplit","stateMutability":"nonpayable","inputs":[{"name":"nft","type":"address"},{"name":"id","type":"uint256"},{"name":"wa","type":"address"},{"name":"wb","type":"address"},{"name":"wc","type":"address"},{"name":"a","type":"uint96"},{"name":"b","type":"uint96"},{"name":"c","type":"uint96"}],"outputs":[]},
  {"type":"function","name":"payNative","stateMutability":"payable","inputs":[{"name":"nft","type":"address"},{"name":"id","type":"uint256"}],"outputs":[]}
];
