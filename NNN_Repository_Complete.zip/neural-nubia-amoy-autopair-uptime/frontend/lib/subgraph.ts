export const SUBGRAPH_URL = process.env.NEXT_PUBLIC_SUBGRAPH_URL || ""

export async function gql<T=any>(query: string, vars?: Record<string, any>): Promise<T> {
  if (!SUBGRAPH_URL) throw new Error("NEXT_PUBLIC_SUBGRAPH_URL not set")
  const res = await fetch(SUBGRAPH_URL, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ query, variables: vars||{} })
  })
  if(!res.ok) throw new Error("Subgraph HTTP error: "+res.status)
  const json = await res.json()
  if(json.errors) throw new Error(json.errors[0]?.message || "Subgraph error")
  return json.data
}

// TODO: add totalizers (TVL, citizenCount, royaltiesMonth, nodeOnline)


export async function getNetworkStats(){
  const q = `{ networkStats(id: "global"){ tvl citizens royalties30d alerts } }`
  const d = await gql(q)
  return d.networkStats || { tvl: "0", citizens: "0", royalties30d: "0", alerts: "0" }
}
