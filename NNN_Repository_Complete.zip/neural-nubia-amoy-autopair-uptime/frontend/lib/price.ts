import { createPublicClient, http, getContract } from 'viem'
import { defineChain } from 'viem'
export const chainId = Number(process.env.NEXT_PUBLIC_CHAIN_ID || '80002')
export const rpc = process.env.NEXT_PUBLIC_CHAIN_RPC || 'https://rpc-amoy.polygon.technology'
export const SUBNET = defineChain({ id: chainId, name: 'Neural Nubia (Amoy)', nativeCurrency: { name:'POL', symbol:'POL', decimals:18 }, rpcUrls:{ default:{ http:[rpc] } } })

const PAIR = process.env.NEXT_PUBLIC_PAIR_ADDRESS as `0x${string}` | undefined
const USDC_DECIMALS = Number(process.env.NEXT_PUBLIC_USDC_DECIMALS || '6')
const client = createPublicClient({ chain: SUBNET, transport: http(rpc) })

const ABI_PAIR = [
  { "type":"function","name":"getReserves","stateMutability":"view","inputs":[],"outputs":[{"type":"uint112"},{"type":"uint112"},{"type":"uint32"}] },
  { "type":"function","name":"token0","stateMutability":"view","inputs":[],"outputs":[{"type":"address"}] },
  { "type":"function","name":"token1","stateMutability":"view","inputs":[],"outputs":[{"type":"address"}] }
] as const

export async function getNncPrice(): Promise<{ price:number, reserves?:any }|null> {
  if(!PAIR) return null
  const c = getContract({ address: PAIR, abi: ABI_PAIR, client })
  const [r0, r1, _] = await c.read.getReserves()
  const t0 = await c.read.token0()
  const t1 = await c.read.token1()
  // Assume pair is NNC/USDC where USDC is token1 (decimals 6) and NNC is 18
  // We won't fetch decimals on-chain to keep it light; use env for USDC
  const R0 = Number(r0) / 1e18
  const R1 = Number(r1) / (10 ** USDC_DECIMALS)
  // price in USDC per NNC
  const price = R1 / R0
  return { price, reserves: { R0, R1, t0, t1 } }
}


export async function getPairAddress(tokenA: `0x${string}`, tokenB: `0x${string}`): Promise<`0x${string}`> {
  const FACTORY = process.env.NEXT_PUBLIC_FACTORY_ADDRESS as `0x${string}`
  const ABI_FACTORY = [{ "type":"function","name":"getPair","inputs":[{"type":"address"},{"type":"address"}],"outputs":[{"type":"address"}],"stateMutability":"view" }] as const
  if(!FACTORY) throw new Error("NEXT_PUBLIC_FACTORY_ADDRESS required")
  const factory = getContract({ address: FACTORY, abi: ABI_FACTORY, client })
  return await factory.read.getPair([tokenA, tokenB])
}
