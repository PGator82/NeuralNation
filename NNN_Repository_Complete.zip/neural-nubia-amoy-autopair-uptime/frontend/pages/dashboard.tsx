import { useEffect, useState } from 'react'
import { gql, getNetworkStats } from '@/lib/subgraph'

type Proposal = { id: string, description: string, state: string, votesFor: string, votesAgainst: string, votesAbstain: string, createdAt: string }
type Stake = { id: string, amount: string }
type SecurityAlert = { id: string, reporter: string, severity: number, timestamp: string, bountyPaid: boolean }

export default function Dashboard(){
  const [proposals, setProposals] = useState<Proposal[]>([])
  const [stakes, setStakes] = useState<Stake[]>([])
  const [alerts, setAlerts] = useState<SecurityAlert[]>([])
  const [loading, setLoading]
  const [stats, setStats] = useState<any>({ tvl:'0', citizens:'0', royalties30d:'0', alerts:'0' }) = useState(true)
  const [error, setError] = useState<string|undefined>()

  useEffect(()=>{
    const HEARTBEAT_URL = process.env.NEXT_PUBLIC_HEARTBEAT_URL || '';

    (async ()=>{
      try{
        const s = await getNetworkStats(); setStats(s);
        const data = await gql(`
          {
            proposals(first: 10, orderBy: createdAt, orderDirection: desc){
              id description state votesFor votesAgainst votesAbstain createdAt
            }
            stakes(first: 10, orderBy: updatedAt, orderDirection: desc){
              id amount
            }
            securityAlerts(first: 10, orderBy: timestamp, orderDirection: desc){
              id reporter severity timestamp bountyPaid
            }
          }
        `)
        setProposals(data.proposals||[])
        setStakes(data.stakes||[])
        setAlerts(data.securityAlerts||[])
        if(HEARTBEAT_URL){ try{ const n = await fetch(HEARTBEAT_URL + '/nodes').then(r=>r.json()); (window as any).__nodes = n.nodes || []; } catch{} }
      }catch(e:any){
        setError(e?.message || "Failed to load subgraph")
      }finally{
        setLoading(false)
      }
    })()
  }, [])

  return (
    <main style={{maxWidth:1000,margin:'2rem auto',padding:'0 1rem'}}>
      <h1>Neural Nubia — Network Dashboard</h1>

      <div className="card" style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'12px'}}>
        <div><div style={{opacity:.7}}>TVL (Staking)</div><div style={{fontSize:'1.4rem'}}>{String(stats.tvl)}</div></div>
        <div><div style={{opacity:.7}}>Active Citizens</div><div style={{fontSize:'1.4rem'}}>{String(stats.citizens)}</div></div>
        <div><div style={{opacity:.7}}>Monthly Royalties</div><div style={{fontSize:'1.4rem'}}>{String(stats.royalties30d)}</div></div>
        <div><div style={{opacity:.7}}>Active Nodes</div><div style={{fontSize:'1.4rem'}}>{((window as any).__nodes||[]).filter((x:any)=>x.online).length}</div></div>
      </div>
    
      {!loading && error && <div className="card"><b>Error:</b> {error}</div>}
      {loading && <div className="card">Loading...</div>}

      <div className="card">
        <h2>Latest Proposals</h2>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th align="left">ID</th><th align="left">State</th><th align="left">Votes (For/Against/Abstain)</th><th align="left">Description</th></tr></thead>
          <tbody>
            {proposals.map(p=>(
              <tr key={p.id}><td>{p.id}</td><td>{p.state}</td><td>{p.votesFor}/{p.votesAgainst}/{p.votesAbstain}</td><td>{p.description}</td></tr>
            ))}
            {proposals.length===0 && <tr><td colSpan={4} style={{opacity:.7}}>No proposals yet.</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2>Recent Staking Activity</h2>
        <ul>
          {stakes.map(s=>(<li key={s.id}><b>User:</b> {s.id} — <b>Staked:</b> {s.amount}</li>))}
          {stakes.length===0 && <li style={{opacity:.7}}>No staking events yet.</li>}
        </ul>
      </div>

      <div className="card">
        <h2>Security Alerts</h2>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th align="left">Fingerprint</th><th align="left">Reporter</th><th align="left">Severity</th><th align="left">Bounty</th></tr></thead>
          <tbody>
            {alerts.map(a=>(
              <tr key={a.id}><td style={{fontFamily:'monospace'}}>{a.id.slice(0,10)}…</td><td>{a.reporter}</td><td>{a.severity}</td><td>{a.bountyPaid ? 'Paid' : 'Pending'}</td></tr>
            ))}
            {alerts.length===0 && <tr><td colSpan={4} style={{opacity:.7}}>No alerts yet.</td></tr>}
          </tbody>
        </table>
      </div>
    
    <section>
      <h2>Citizen Nodes</h2>
      <NodeList />
    </section>
    
      <div className="card">
        <h2>Nodes Online</h2>
        <p style={{opacity:.7}}>Source: Heartbeat API ({process.env.NEXT_PUBLIC_HEARTBEAT_URL || 'not set'})</p>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th align="left">Status</th><th align="left">Node</th><th align="left">Wallet</th><th align="left">Uptime (24h)</th></tr></thead>
          <tbody>
            {((window as any).__nodes||[]).map((n:any)=> (
              <tr key={n.nodeId}>
                <td>{n.online ? '🟢' : '🔴'}</td>
                <td style={{fontFamily:'monospace'}}>{n.nodeId}</td>
                <td style={{fontFamily:'monospace'}}>{n.wallet}</td>
                <td>{n.uptimePct?.toFixed ? n.uptimePct.toFixed(1) : n.uptimePct}%</td>
              </tr>
            ))}
            {(((window as any).__nodes||[]).length===0) && <tr><td colSpan={4} style={{opacity:.7}}>No heartbeats yet.</td></tr>}
          </tbody>
        </table>
      </div>
    
    </main>

function NodeList(){
  const [nodes, setNodes] = useState<any[]>([])
  const HEARTBEAT_URL = process.env.NEXT_PUBLIC_HEARTBEAT_URL || ''
  useEffect(()=>{
    if(!HEARTBEAT_URL) return
    const run = async()=>{
      try{
        const data = await fetch(HEARTBEAT_URL + '/nodes').then(r=>r.json())
        setNodes(data.nodes || [])
      }catch(e){}
    }
    run()
    const id = setInterval(run, 60000)
    return ()=>clearInterval(id)
  },[HEARTBEAT_URL])
  if(!nodes.length) return <p>No node data yet.</p>
  return (
    <table style={{width:'100%', fontSize:'0.9rem'}}>
      <thead><tr><th>Wallet</th><th>Status</th><th>Uptime%</th><th>Last Beat</th></tr></thead>
      <tbody>
        {nodes.map((n,i)=>(
          <tr key={i}>
            <td>{n.wallet}</td>
            <td style={{color:n.online?'green':'red'}}>{n.online?'Online':'Offline'}</td>
            <td>{n.uptime ? (n.uptime*100).toFixed(1)+'%' : '—'}</td>
            <td>{new Date(n.timestamp*1000).toLocaleString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

  )
}
