import { useState } from 'react'
import { useAccount, useWriteContract } from 'wagmi'
import { keccak256, toBytes, encodeFunctionData } from 'viem'

const ABI_GOV = [
  {"type":"function","name":"propose","inputs":[{"name":"targets","type":"address[]"},{"name":"values","type":"uint256[]"},{"name":"calldatas","type":"bytes[]"},{"name":"description","type":"string"}],"outputs":[{"type":"uint256"}],"stateMutability":"nonpayable"},
  {"type":"function","name":"castVote","inputs":[{"name":"proposalId","type":"uint256"},{"name":"support","type":"uint8"}],"outputs":[{"type":"uint256"}],"stateMutability":"nonpayable"},
  {"type":"function","name":"queue","inputs":[{"name":"targets","type":"address[]"},{"name":"values","type":"uint256[]"},{"name":"calldatas","type":"bytes[]"},{"name":"descriptionHash","type":"bytes32"}],"outputs":[{"type":"uint256"}],"stateMutability":"nonpayable"},
  {"type":"function","name":"execute","inputs":[{"name":"targets","type":"address[]"},{"name":"values","type":"uint256[]"},{"name":"calldatas","type":"bytes[]"},{"name":"descriptionHash","type":"bytes32"}],"outputs":[{"type":"uint256"}],"stateMutability":"payable"}
]

// Minimal ABI for NNCStaking.setRewardRate(uint256)
const ABI_STAKING = [{
  "type":"function","name":"setRewardRate","inputs":[{"name":"rate","type":"uint256"}],"outputs":[],"stateMutability":"nonpayable"
}]

export default function GovernMVP(){
  const { isConnected } = useAccount()
  const { writeContract } = useWriteContract()

  const [gov, setGov] = useState('0x...')

  // Generic proposal builder
  const [targets, setTargets] = useState('[]')
  const [values, setValues] = useState('[]')
  const [calldatas, setCalldatas] = useState('[]')
  const [desc, setDesc] = useState('Set staking reward rate')

  // Voting
  const [proposalId, setProposalId] = useState('0')
  const [support, setSupport] = useState('1') // 0=Against,1=For,2=Abstain

  // Auto-computed desc hash
  const descHash = keccak256(toBytes(desc))

  // Helper: build calldata to set staking reward
  const [stakingAddr, setStakingAddr] = useState('0x...')
  const [newRate, setNewRate] = useState('0')
  const makeSetRate = () => {
    try{
      const data = encodeFunctionData({ abi: ABI_STAKING as any, functionName: 'setRewardRate', args: [BigInt(newRate)] })
      setTargets(JSON.stringify([stakingAddr]))
      setValues(JSON.stringify([0]))
      setCalldatas(JSON.stringify([data]))
      setDesc(`Set staking reward to ${newRate}`)
      alert('Calldata prepared below. You can now Propose.')
    }catch(e:any){ alert(e?.message || 'encode failed') }
  }

  const propose = async () => {
    if(!isConnected) return alert('Connect')
    let t = JSON.parse(targets); let v = JSON.parse(values); let c = JSON.parse(calldatas)
    try{
      await writeContract({ address: gov as `0x${string}`, abi: ABI_GOV, functionName:'propose', args:[t,v,c,desc] })
      alert('Proposal sent. Copy proposalId from tx receipt/logs.')
    }catch(e:any){ alert(e?.shortMessage || e?.message || 'tx failed') }
  }

  const vote = async () => {
    if(!isConnected) return alert('Connect')
    try{ await writeContract({ address: gov as `0x${string}`, abi: ABI_GOV, functionName:'castVote', args:[proposalId, Number(support)] }); alert('Voted') }
    catch(e:any){ alert(e?.shortMessage || e?.message || 'tx failed') }
  }

  const queue = async () => {
    if(!isConnected) return alert('Connect')
    let t = JSON.parse(targets); let v = JSON.parse(values); let c = JSON.parse(calldatas)
    try{ await writeContract({ address: gov as `0x${string}`, abi: ABI_GOV, functionName:'queue', args:[t,v,c,descHash] }); alert('Queued; wait timelock then Execute') }
    catch(e:any){ alert(e?.shortMessage || e?.message || 'queue failed') }
  }

  const execute = async () => {
    if(!isConnected) return alert('Connect')
    let t = JSON.parse(targets); let v = JSON.parse(values); let c = JSON.parse(calldatas)
    try{ await writeContract({ address: gov as `0x${string}`, abi: ABI_GOV, functionName:'execute', args:[t,v,c,descHash], value: 0 }); alert('Executed') }
    catch(e:any){ alert(e?.shortMessage || e?.message || 'execute failed') }
  }

  return (
    <main style={{maxWidth:900,margin:'2rem auto',padding:'0 1rem'}}>
      <h1>Governance (MVP)</h1>

      <div className="card">
        <h2>Quick Builder: Set Staking Reward</h2>
        <label>Staking Contract</label>
        <input value={stakingAddr} onChange={e=>setStakingAddr(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <label>New Reward Rate (wei per sec)</label>
        <input value={newRate} onChange={e=>setNewRate(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <button className="btn" onClick={makeSetRate}>Prepare Proposal</button>
      </div>

      <div className="card">
        <h2>Create Proposal (Advanced)</h2>
        <label>Governor Address</label>
        <input value={gov} onChange={e=>setGov(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <label>Targets (JSON address[])</label>
        <input value={targets} onChange={e=>setTargets(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <label>Values (JSON uint256[])</label>
        <input value={values} onChange={e=>setValues(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <label>Calldatas (JSON bytes[])</label>
        <input value={calldatas} onChange={e=>setCalldatas(e.target.value)} style={{width:'100%',padding:'8px',margin:'8px 0'}}/>
        <label>Description</label>
        <input value={desc} onChange={e=>setDesc(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <p><b>Description Hash (auto):</b> {descHash}</p>
        <button className="btn" onClick={propose}>Propose</button>
      </div>

      <div className="card">
        <h2>Vote</h2>
        <label>Proposal ID</label>
        <input value={proposalId} onChange={e=>setProposalId(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div><label>Support (0/1/2)</label><input value={support} onChange={e=>setSupport(e.target.value)} style={{width:'100%',padding:8}}/></div>
          <div><button className="btn" onClick={vote}>Cast Vote</button></div>
        </div>
      </div>

      <div className="card">
        <h2>Queue & Execute</h2>
        <p>Uses the computed Description Hash above; keep Targets/Values/Calldatas unchanged.</p>
        <div style={{display:'flex',gap:12}}>
          <button className="btn" onClick={queue}>Queue</button>
          <button className="btn" onClick={execute}>Execute</button>
        </div>
      </div>
    </main>
  )
}
