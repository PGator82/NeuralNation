import Link from 'next/link'
import { useEffect, useState } from 'react'
import { getNncPrice, resolvePairAddress } from '@/lib/price'
export default function Home(){
  return (<main style={{maxWidth:800,margin:'2rem auto',padding:'0 1rem'}}>
    <h1>Neural Nubia Network</h1>
    <PriceCard />
    <p>From the Old Kingdom to the New Code.</p>
    <div className="card"><h2>Start Here</h2><ul>
      <li><a href="/onboard">Claim Starter NNC (Onboard)</a></li>
      <li><Link href="/passport">Mint your <b>Neural ID</b></Link></li>
      <li><Link href="/stake">Stake NNC</Link></li>
      <li><Link href="/vault">Creator Vault (mint & royalties)</Link></li>
      <li><Link href="/security">Cybersecurity Node</Link></li>
          <li><a href="/dashboard">Network Dashboard (Subgraph)</a></li>
    </ul></div>
    <div className="card">
      <h2>NNC Price</h2>
      <p>Coming soon: live price from QuickSwap pool.</p>
      <a href="https://quickswap.exchange" target="_blank" rel="noreferrer">Swap on QuickSwap</a>
    </div>
    

    </main>)

function PriceCard(){
  const [p, setP] = useState<number|null>(null)
  const [err, setErr] = useState<string|undefined>()
  useEffect(()=>{ (async()=>{ try{ 
      // resolve pair first if env not set
      const pair = await resolvePairAddress()
      if(!pair){ setErr('Pair not found. Set NEXT_PUBLIC_PAIR_ADDRESS or FACTORY+NNC+USDC.'); return }
      const r = await getNncPrice(); if(r) setP(r.price); 
    } catch(e:any){ setErr(e?.message||'price error') } })() }, [])
  return (<div className="card"><h2>NNC Price</h2>
    {!p && !err && <p>Loading…</p>}
    {err && <p style={{opacity:.7}}>{err} — set NEXT_PUBLIC_PAIR_ADDRESS + USDC decimals.</p>}
    {p !== null && <p><b>${p.toFixed(6)} USDC</b></p>}
    <a href="https://quickswap.exchange" target="_blank" rel="noreferrer">Swap on QuickSwap</a>
  </div>)
}
)
}
