#!/usr/bin/env python3

"""
Simulate constant-product AMM price impact for NNC paired with USDC or MATIC.
Inputs:
- initial_NNC (token0)
- initial_USDC (token1)  (or MATIC)
- trade_sizes (list)
Outputs price after buys/sells and slippage.
"""

import math, json

def simulate(initial_token0, initial_token1, trade_sizes):
    # x*y = k ; price (token1 per token0) = y/x
    x = float(initial_token0)
    y = float(initial_token1)
    k = x*y
    price0 = y/x
    results = {"initial_price": price0, "scenarios": []}
    for t in trade_sizes:
        # Buy NNC with token1 (spend token1 to get token0)
        y_in = t
        new_y = y + y_in
        new_x = k / new_y
        token0_out = x - new_x
        price_after_buy = new_y / new_x
        buy_slippage = (price_after_buy - price0) / price0 * 100.0

        # Sell NNC for token1 (sell token0 to get token1)
        x_in = t / price0  # approx convert spend to token0 terms
        new_x2 = x + x_in
        new_y2 = k / new_x2
        token1_out = y - new_y2
        price_after_sell = new_y2 / new_x2
        sell_slippage = (price0 - price_after_sell) / price0 * 100.0

        results["scenarios"].append({
            "trade_in_token1": t,
            "buy": {"token0_out": token0_out, "price_after": price_after_buy, "slippage_pct": buy_slippage},
            "sell": {"token1_out": token1_out, "price_after": price_after_sell, "slippage_pct": sell_slippage},
        })
    return results

if __name__ == "__main__":
    # Example: seed 1,000,000 NNC and 100,000 USDC (price 0.10 USDC/NNC)
    trade_sizes = [100, 1000, 5000, 10000, 25000, 50000]
    out = simulate(1_000_000, 100_000, trade_sizes)
    print(json.dumps(out, indent=2))
