#!/usr/bin/env python3
import os, time, json, requests, socket

API = os.environ.get("NN_HEARTBEAT_URL","http://localhost:8788/beat")
WALLET = os.environ.get("NN_WALLET","")
NODE_ID = os.environ.get("NN_NODE_ID", socket.gethostname())

def main():
  if not WALLET:
    print("Set NN_WALLET=0x..."); return
  while True:
    try:
      requests.post(API, json={"nodeId": NODE_ID, "wallet": WALLET, "ts": int(time.time())}, timeout=3)
    except Exception as e:
      pass
    time.sleep(60)

if __name__ == "__main__":
  main()
