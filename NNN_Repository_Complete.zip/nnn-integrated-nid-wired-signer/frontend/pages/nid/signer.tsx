import { useState } from 'react'
import { useAccount, useSignMessage } from 'wagmi'
import { keccak256, stringToBytes, toBytes } from 'viem'
export default function VerifierSigner(){
  const { address, chain } = useAccount()
  const { signMessageAsync } = useSignMessage()
  const [user, setUser] = useState('0x'); const [name, setName] = useState(''); const [cid, setCid] = useState('')
  const [sig, setSig] = useState(''); const [digest, setDigest] = useState('')
  const chainId = chain?.id || Number(process.env.NEXT_PUBLIC_CHAIN_ID || 80002)
  const citizenHash = keccak256(stringToBytes(`${name}:${cid}`))
  async function makeSig(){
    if(!address) return alert('Connect as a verifier')
    const preimage = new Uint8Array([...stringToBytes("NNN:MintNID"), ...toBytes(BigInt(chainId)), ...toBytes(user as `0x${string}`), ...toBytes(citizenHash as `0x${string}`)])
    const d = keccak256(preimage); setDigest(d)
    const s = await signMessageAsync({ message: { raw: toBytes(d) } }); setSig(s)
  }
  return (<main style={{maxWidth:800,margin:'2rem auto',padding:'0 1rem'}}>
    <h1>Verifier Signer — Neural ID</h1>
    <label>Citizen Wallet (0x…)</label><input value={user} onChange={e=>setUser(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
    <label>Citizen Name/Handle</label><input value={name} onChange={e=>setName(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
    <label>Proof IPFS CID</label><input value={cid} onChange={e=>setCid(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
    <button className="btn" onClick={makeSig}>Sign Authorization</button>
    {digest && <p style={{marginTop:12}}><b>Digest:</b> <code>{digest}</code></p>}
    {sig && <p><b>Signature:</b> <code style={{wordBreak:'break-all'}}>{sig}</code></p>}
  </main>)
}
