# NNN Integrated: Neural ID wired + Verifier Signer + Staking V2

## Contracts
- NeuralNubianCoin.sol (capped/burnable/pausable)
- NeuralID.sol (soulbound)
- NeuralIDMinter.sol (NNC fee + verifier signature)
- NNCStakingV2.sol (NID-gated staking with penalties)

## Scripts
- scripts/deploy_all.ts — deploys all and sets minter as issuer
- scripts/ownership_handoff_safe.ts — transfers ownership to Gnosis Safe

## Frontend Pages
- / (home links)
- /stake — Stake V2 UI
- /nid/mint — citizen mint
- /nid/admin — issuer controls
- /nid/signer — verifier signature tool

Set env in `frontend/.env.local` then run your Next app with Wagmi/viem.
