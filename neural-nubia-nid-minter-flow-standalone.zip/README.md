
# Neural Nubia — Neural ID Minter Flow (Standalone)

## Contracts
- `NeuralNubianCoin.sol` — NNC with capped supply
- `NeuralID.sol` — soulbound citizenship NFT (issuer-gated)
- `NeuralIDMinter.sol` — self-service minter: NNC fee + verifier signature

### Verifier Signature
Verifier signs: `keccak256("NNN:MintNID", chainId, wallet, citizenHash)` as an **Ethereum signed message**.
Citizen submits `citizenHash = keccak256(abi.encodePacked(name, ":", ipfsCID))` and the `sig`.

## Deploy (Hardhat)
```
npx hardhat compile
npx hardhat run scripts/deploy_nid_flow.ts --network amoy
```

## Frontend (Next/Wagmi-style pages)
- `frontend/pages/nid_mint.tsx`
- `frontend/pages/nid_admin.tsx`

Set env:
```
NEXT_PUBLIC_NNC_ADDRESS=0x...
NEXT_PUBLIC_NEURALID_ADDRESS=0x...
NEXT_PUBLIC_NID_MINTER=0x...
```

## Flow
1) Add at least one **verifier** with `setVerifier(address, true)`
2) Citizen **approves** NNC to minter, submits **name + IPFS CID + signature**
3) Minter takes fee, verifies signature, calls `NeuralID.mint()`
