#!/usr/bin/env bash
set -euo pipefail

UNIT="nnn-docker-compose.service"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
UNIT_SRC="${SRC_DIR}/${UNIT}"
UNIT_DST="$HOME/.config/systemd/user/${UNIT}"

mkdir -p "$HOME/.config/systemd/user"
cp "$UNIT_SRC" "$UNIT_DST"

echo "Reloading user systemd..."
systemctl --user daemon-reload

echo "Enabling ${UNIT} to start at login..."
systemctl --user enable "${UNIT}"

echo "Starting ${UNIT} now..."
systemctl --user start "${UNIT}"

echo "Status:"
systemctl --user status "${UNIT}" --no-pager -l || true

echo "Tip: enable lingering so the service runs without an active login:"
echo "sudo loginctl enable-linger $(whoami)"
