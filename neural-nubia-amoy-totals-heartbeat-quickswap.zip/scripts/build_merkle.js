#!/usr/bin/env node
import fs from 'fs'
import keccak256 from 'keccak256'
import { MerkleTree } from 'merkletreejs'

/**
 * Usage:
 * node scripts/build_merkle.js airdrop.json
 * airdrop.json = [ { "address": "0x...", "amount": "1000000000000000000" }, ... ]
 */
const file = process.argv[2]
if(!file) {
  console.error('Usage: node scripts/build_merkle.js airdrop.json')
  process.exit(1)
}
const raw = fs.readFileSync(file)
const list = JSON.parse(raw)

const leaves = list.map(x => keccak256(x.address.toLowerCase() + x.amount.toString()))
const tree = new MerkleTree(leaves, keccak256, { sortPairs: true })
const root = tree.getHexRoot()
console.log('Merkle Root:', root)

list.forEach((x,i) => {
  const leaf = keccak256(x.address.toLowerCase() + x.amount.toString())
  const proof = tree.getHexProof(leaf)
  console.log(`Address ${x.address} amount ${x.amount} proof:`, JSON.stringify(proof))
})

// Save outputs
fs.writeFileSync('merkle_root.txt', root)
fs.writeFileSync('merkle_proofs.json', JSON.stringify(list.map((x) => {
  const leaf = keccak256(x.address.toLowerCase() + x.amount.toString())
  const proof = tree.getHexProof(leaf)
  return { ...x, proof }
}), null, 2))
