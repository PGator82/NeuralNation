import { Proposal, Vote } from '../generated/schema'
import { ProposalCreated, VoteCast } from '../generated/Governor/Governor'

export function handleProposalCreated(event: ProposalCreated): void {
  let id = event.params.proposalId.toHex()
  let p = new Proposal(id)
  p.proposer = event.params.proposer
  p.description = event.params.description
  p.state = "Active"
  p.votesFor = BigInt.fromI32(0)
  p.votesAgainst = BigInt.fromI32(0)
  p.votesAbstain = BigInt.fromI32(0)
  p.createdAt = event.block.timestamp
  p.save()
}

export function handleVoteCast(event: VoteCast): void {
  let id = event.transaction.hash.toHex() + "-" + event.logIndex.toString()
  let v = new Vote(id)
  v.proposal = event.params.proposalId.toHex()
  v.voter = event.params.voter
  v.support = event.params.support
  v.weight = event.params.weight
  v.timestamp = event.block.timestamp
  v.save()
}
