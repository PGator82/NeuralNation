import { SecurityAlert } from '../generated/schema'
import { AlertPosted, BountyPaid } from '../generated/SecurityOracle/Oracle'

export function handleAlertPosted(event: AlertPosted): void {
  let id = event.params.fingerprint.toHex()
  let s = new SecurityAlert(id)
  s.reporter = event.params.reporter
  s.fingerprint = event.params.fingerprint
  s.severity = event.params.severity
  s.timestamp = event.params.timestamp
  s.bountyPaid = false
  s.save()
}

export function handleBountyPaid(event: BountyPaid): void {
  let id = event.params.fingerprint.toHex()
  let s = SecurityAlert.load(id)
  if (s == null) return
  s.bountyPaid = true
  s.save()
}
