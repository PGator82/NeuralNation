import type { AppProps } from 'next/app'
import '@/styles/globals.css'
import { WagmiConfig, createConfig, http } from 'wagmi'
import { defineChain } from 'viem'
const chainId = Number(process.env.NEXT_PUBLIC_CHAIN_ID || '80002')
const rpc = process.env.NEXT_PUBLIC_CHAIN_RPC || 'https://rpc-amoy.polygon.technology'
const custom = defineChain({ id: chainId, name: 'Neural Nubia (Amoy)', nativeCurrency: { name: 'POL', symbol: 'POL', decimals: 18 }, rpcUrls: { default: { http: [rpc] } } })
const config = createConfig({ chains: [custom], transports: { [custom.id]: http(rpc) } })
export default function App({ Component, pageProps }: AppProps) { return (<WagmiConfig config={config}><Component {...pageProps} /></WagmiConfig>) }
