export default function Security(){
  return (<main style={{maxWidth:820,margin:'2rem auto',padding:'0 1rem'}}>
    <h1>Cybersecurity Node</h1>
    <p>Run Suricata + Loki + Grafana on your Nubian Node and earn bounties for verified alerts.</p>
    <ol>
      <li>Go to <code>/security</code> folder in the repo</li>
      <li><code>docker compose up -d</code></li>
      <li>Open Grafana at <code>http://localhost:3000</code> (anonymous)</li>
      <li>Tune rules in <code>security/suricata/suricata.rules</code></li>
    </ol>
  </main>)
}