import { useState } from 'react'
import { useAccount, useWriteContract } from 'wagmi'
import { ADDR_MORE, ABI_CNFT, ABI_Royalty } from '@/lib/contracts'
export default function Vault(){ const { address,isConnected }=useAccount(); const { writeContract }=useWriteContract(); const [uri,setUri]=useState('ipfs://...'); const [tokenId,setTokenId]=useState('0'); const [wa,setWa]=useState('0x...'); const [wb,setWb]=useState('0x...'); const [wc,setWc]=useState('0x...'); const [a,setA]=useState('5000'); const [b,setB]=useState('3000'); const [c,setC]=useState('2000'); const [price,setPrice]=useState('0');
  const mint=async()=>{ if(!isConnected) return alert('Connect'); await writeContract({address:ADDR_MORE.CNFT as `0x${string}`, abi:ABI_CNFT, functionName:'mint', args:[address,uri]}); alert('Minted (check explorer)'); }
  const setSplit=async()=>{ await writeContract({address:ADDR_MORE.ROYALTY as `0x${string}`, abi:ABI_Royalty, functionName:'setSplit', args:[ADDR_MORE.CNFT, BigInt(tokenId), wa, wb, wc, BigInt(a), BigInt(b), BigInt(c)]}); alert('Split set'); }
  const pay=async()=>{ await writeContract({address:ADDR_MORE.ROYALTY as `0x${string}`, abi:ABI_Royalty, functionName:'payNative', args:[ADDR_MORE.CNFT, BigInt(tokenId)], value: BigInt(price) }); alert('Paid'); }
  return (<main style={{maxWidth:820,margin:'2rem auto',padding:'0 1rem'}}><h1>Creator Vault</h1><div className="card"><h2>Mint</h2><input value={uri} onChange={e=>setUri(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/><button className="btn" onClick={mint}>Mint to me</button></div>
    <div className="card"><h2>Royalty Split</h2><input value={tokenId} onChange={e=>setTokenId(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}><div><label>Creator</label><input value={wa} onChange={e=>setWa(e.target.value)} style={{width:'100%',padding:8}}/></div>
    <div><label>Treasury</label><input value={wb} onChange={e=>setWb(e.target.value)} style={{width:'100%',padding:8}}/></div>
    <div><label>Healing</label><input value={wc} onChange={e=>setWc(e.target.value)} style={{width:'100%',padding:8}}/></div>
    <div><label>Creator bps</label><input value={a} onChange={e=>setA(e.target.value)} style={{width:'100%',padding:8}}/></div>
    <div><label>Treasury bps</label><input value={b} onChange={e=>setB(e.target.value)} style={{width:'100%',padding:8}}/></div>
    <div><label>Healing bps</label><input value={c} onChange={e=>setC(e.target.value)} style={{width:'100%',padding:8}}/></div></div>
    <button className="btn" onClick={setSplit} style={{marginTop:12}}>Set Split</button></div>
    <div className="card"><h2>Test Payment</h2><input value={price} onChange={e=>setPrice(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/><button className="btn" onClick={pay}>Pay & Split</button></div></main>) }
