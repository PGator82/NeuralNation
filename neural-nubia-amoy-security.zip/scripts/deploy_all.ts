import { ethers } from "hardhat";
async function main(){
  const [d] = await ethers.getSigners(); console.log("Deployer:", d.address);
  const NNC = await ethers.getContractFactory("NeuralNubianCoin"); const nnc = await NNC.deploy(d.address, ethers.parseUnits("100000000",18)); await nnc.waitForDeployment(); console.log("NNC:", await nnc.getAddress());
  const NID = await ethers.getContractFactory("NeuralID"); const nid = await NID.deploy(); await nid.waitForDeployment(); console.log("NeuralID:", await nid.getAddress());
  const Royal = await ethers.getContractFactory("RoyaltyRouter"); const royal = await Royal.deploy(); await royal.waitForDeployment(); console.log("RoyaltyRouter:", await royal.getAddress());
  const Edu = await ethers.getContractFactory("EducationRewards"); const edu = await Edu.deploy(await nnc.getAddress()); await edu.waitForDeployment(); console.log("EducationRewards:", await edu.getAddress());
  const Heal = await ethers.getContractFactory("HealToEarn"); const heal = await Heal.deploy(await nnc.getAddress()); await heal.waitForDeployment(); console.log("HealToEarn:", await heal.getAddress());
  const Votes = await ethers.getContractFactory("NNCVotes"); const votes = await Votes.deploy(); await votes.waitForDeployment(); console.log("NNCVotes:", await votes.getAddress());
  const Timelock = await ethers.getContractFactory("NeuralTimelock"); const tl = await Timelock.deploy([d.address],[d.address], d.address, 172800); await tl.waitForDeployment(); console.log("NeuralTimelock:", await tl.getAddress());
  const Gov = await ethers.getContractFactory("NeuralGovernor"); const gov = await Gov.deploy(await votes.getAddress(), tl.getAddress()); await gov.waitForDeployment(); console.log("NeuralGovernor:", await gov.getAddress());
  const Staking = await ethers.getContractFactory("NNCStaking"); const staking = await Staking.deploy(await nnc.getAddress(), ethers.parseUnits("0.000001",18)); await staking.waitForDeployment(); console.log("NNCStaking:", await staking.getAddress());
  const CNFT = await ethers.getContractFactory("CulturalNFT"); const cnft = await CNFT.deploy(); await cnft.waitForDeployment(); console.log("CulturalNFT:", await cnft.getAddress());
}
main().catch((e)=>{ console.error(e); process.exit(1); });
