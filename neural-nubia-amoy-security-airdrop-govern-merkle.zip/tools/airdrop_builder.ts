// tools/airdrop_builder.ts
// Usage:
//   npx ts-node tools/airdrop_builder.ts input.csv output.json
// CSV format (no header): address,amount_wei
import fs from 'fs'
import crypto from 'crypto'

type Leaf = { address: string, amount: string }
type Node = { hash: Buffer, left?: Node, right?: Node, leaf?: Leaf }

function keccak(data: Buffer): Buffer {
  return crypto.createHash('sha3-256').update(data).digest()
}

function leafHash(leaf: Leaf): Buffer {
  const packed = Buffer.concat([
    Buffer.from(leaf.address.replace(/^0x/,'').padStart(40,'0'), 'hex'),
    Buffer.from(BigInt(leaf.amount).toString(16).padStart(64,'0'), 'hex'),
  ])
  return keccak(packed)
}

function buildTree(leaves: Leaf[]): { root: string, nodes: Node[], layers: Node[][] } {
  const layer0: Node[] = leaves.map(l => ({ hash: leafHash(l), leaf: l }))
  let layers: Node[][] = [layer0]
  let cur = layer0
  while (cur.length > 1) {
    const next: Node[] = []
    for (let i=0; i<cur.length; i+=2) {
      const left = cur[i]
      const right = cur[i+1] || cur[i] // duplicate last if odd
      const [a,b] = Buffer.compare(left.hash, right.hash) <= 0 ? [left.hash, right.hash] : [right.hash, left.hash]
      const parent: Node = { hash: keccak(Buffer.concat([a,b])), left, right }
      next.push(parent)
    }
    layers.push(next)
    cur = next
  }
  const root = cur[0].hash.toString('hex')
  return { root: '0x'+root, nodes: layer0, layers }
}

function getProof(target: Node, layers: Node[][]): string[] {
  const proof: string[] = []
  let idx = layers[0].findIndex(n => n === target)
  for (let level=0; level<layers.length-1; level++) {
    const layer = layers[level]
    const isLast = idx === layer.length-1 && layer.length%2===1
    const pairIdx = isLast ? idx : (idx ^ 1)
    const pairNode = layer[pairIdx]
    proof.push('0x'+pairNode.hash.toString('hex'))
    idx = Math.floor(idx/2)
  }
  // drop the last (root's sibling) element
  proof.pop()
  return proof
}

function main() {
  const [,, input, output] = process.argv
  if(!input || !output) {
    console.error("Usage: npx ts-node tools/airdrop_builder.ts input.csv output.json")
    process.exit(1)
  }
  const rows = fs.readFileSync(input, 'utf8').trim().split(/\r?\n/)
  const leaves: Leaf[] = rows.map(r => {
    const [addr, amt] = r.split(',').map(s=>s.trim())
    if(!addr || !amt) throw new Error("Bad row: "+r)
    return { address: addr, amount: amt }
  })
  const { root, nodes, layers } = buildTree(leaves)
  const proofs: Record<string, { amount: string, proof: string[] }> = {}
  nodes.forEach(n => {
    proofs[n.leaf!.address.toLowerCase()] = { amount: n.leaf!.amount, proof: getProof(n, layers) }
  })
  const out = { merkleRoot: root, entries: proofs }
  fs.writeFileSync(output, JSON.stringify(out, null, 2))
  console.log("Root:", root)
  console.log("Saved:", output)
}

main()
