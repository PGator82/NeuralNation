import { useState } from 'react'
import { useAccount, useWriteContract } from 'wagmi'

const ABI_FAUCET = [
  {"type":"function","name":"claim","stateMutability":"nonpayable","inputs":[],"outputs":[]}
]
const ABI_AIRDROP = [
  {"type":"function","name":"claim","stateMutability":"nonpayable","inputs":[{"name":"amount","type":"uint256"},{"name":"proof","type":"bytes32[]"}],"outputs":[]}
]

export default function Onboard(){
  const { isConnected } = useAccount()
  const { writeContract, isPending } = useWriteContract()
  const [faucetAddr, setFaucetAddr] = useState('0x...')
  const [airdropAddr, setAirdropAddr] = useState('0x...')
  const [amount, setAmount] = useState('0')
  const [proof, setProof] = useState('[]') // JSON array of bytes32

  const claimFaucet = async () => {
    if(!isConnected) return alert('Connect wallet')
    try {
      await writeContract({ address: faucetAddr as `0x${string}`, abi: ABI_FAUCET, functionName: 'claim', args: [] })
      alert('Faucet claim sent')
    } catch(e:any){ alert(e?.shortMessage || e?.message || 'tx failed') }
  }

  const claimAirdrop = async () => {
    if(!isConnected) return alert('Connect wallet')
    let parsed:any = []
    try { parsed = JSON.parse(proof) } catch { return alert('Bad proof JSON') }
    try {
      await writeContract({ address: airdropAddr as `0x${string}`, abi: ABI_AIRDROP, functionName: 'claim', args: [amount, parsed] })
      alert('Airdrop claim sent')
    } catch(e:any){ alert(e?.shortMessage || e?.message || 'tx failed') }
  }

  return (
    <main style={{maxWidth:800,margin:'2rem auto',padding:'0 1rem'}}>
      <h1>Onboard — Claim Starter NNC</h1>

      <div className="card">
        <h2>Faucet</h2>
        <label>Faucet Contract</label>
        <input value={faucetAddr} onChange={e=>setFaucetAddr(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <button className="btn" disabled={isPending} onClick={claimFaucet}>Claim Faucet</button>
        <p style={{opacity:.7}}>Rate-limited per wallet (cooldown applies).</p>
      </div>

      <div className="card">
        <h2>Airdrop</h2>
        <label>Airdrop Contract</label>
        <input value={airdropAddr} onChange={e=>setAirdropAddr(e.target.value)} style={{width:'100%',padding:8,margin:'8px 0'}}/>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
          <div><label>Amount (wei)</label><input value={amount} onChange={e=>setAmount(e.target.value)} style={{width:'100%',padding:8}}/></div>
          <div><label>Proof (JSON bytes32[])</label><input value={proof} onChange={e=>setProof(e.target.value)} style={{width:'100%',padding:8}}/></div>
        </div>
        <button className="btn" disabled={isPending} onClick={claimAirdrop} style={{marginTop:12}}>Claim Airdrop</button>
        <p style={{opacity:.7}}>Paste proof from your airdrop list (we'll add automatic detection via subgraph later).</p>
      </div>
    </main>
  )
}
