import { SecurityAlert, NetworkStats } from '../generated/schema'
 '../generated/schema'
import { AlertPosted, BountyPaid } from '../generated/SecurityOracle/Oracle'

export function handleAlertPosted(event: AlertPosted): void {
  let id = event.params.fingerprint.toHex()
  let s = new SecurityAlert(id)
  s.reporter = event.params.reporter
  s.fingerprint = event.params.fingerprint
  s.severity = event.params.severity
  s.timestamp = event.params.timestamp
  s.bountyPaid = false
  s.save()
  let stats = loadStats(); stats.alerts = stats.alerts.plus(BigInt.fromI32(1)); stats.save()
}

export function handleBountyPaid(event: BountyPaid): void {
  let id = event.params.fingerprint.toHex()
  let s = SecurityAlert.load(id)
  if (s == null) return
  s.bountyPaid = true
  s.save()
  let stats = loadStats(); stats.alerts = stats.alerts.plus(BigInt.fromI32(1)); stats.save()
}


function loadStats(): NetworkStats {
  let s = NetworkStats.load("global")
  if (s == null) { s = new NetworkStats("global"); s.tvl = BigInt.zero(); s.citizens = BigInt.zero(); s.royalties30d = BigInt.zero(); s.alerts = BigInt.zero(); }
  return s as NetworkStats
}
