import { useState } from 'react'
import { useAccount, useWriteContract } from 'wagmi'
import { ADDRS, ABI_NeuralID } from '@/lib/contracts'
export default function Passport(){ const { address, isConnected } = useAccount(); const [hash,setHash]=useState(''); const { writeContract } = useWriteContract();
  const mint=async()=>{ if(!isConnected) return alert('Connect'); if(!hash.startsWith('0x')||hash.length!==66) return alert('bytes32'); await writeContract({address:ADDRS.NEURAL_ID as `0x${string}`, abi:ABI_NeuralID, functionName:'mint', args:[address,hash]}); alert('Submitted'); }
  return (<main style={{maxWidth:800,margin:'2rem auto',padding:'0 1rem'}}><h1>Neural ID</h1><div className="card">
    <input value={hash} onChange={e=>setHash(e.target.value)} placeholder="0x..." style={{width:'100%',padding:8,margin:'8px 0'}}/>
    <button className="btn" onClick={mint}>Mint</button></div></main>) }
