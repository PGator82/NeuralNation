# Neural Nubia — Cybersecurity Node
Run IDS + logs + dashboard and feed on-chain bounties.

1) `cd security && docker compose up -d`
2) Dashboard: http://localhost:3000
3) Edit rules: `security/suricata/suricata.rules`
4) Deploy `SecurityOracle.sol`, call `setReporter(<node wallet>, true)` and `setBounty(...)`
