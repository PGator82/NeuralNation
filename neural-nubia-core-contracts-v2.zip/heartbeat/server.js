// heartbeat/server.js
const express = require('express')
const app = express()
app.use(express.json())

/**
 * nodes: Map<nodeId, { wallet, ts, firstSeen, lastSeen, onlineSeconds }>
 * We approximate uptime over a 24h window by accumulating onlineSeconds whenever beats arrive.
 */
const nodes = new Map()

app.post('/beat', (req, res) => {
  const { nodeId, wallet, ts } = req.body || {}
  if(!nodeId || !wallet || !ts) return res.status(400).json({ ok:false })
  const now = Math.floor(Date.now()/1000)
  let n = nodes.get(nodeId)
  if(!n){
    n = { wallet, ts, firstSeen: ts, lastSeen: ts, onlineSeconds: 0 }
  } else {
    // if last beat within 120s, count elapsed as online time
    const delta = Math.max(0, Math.min(ts - n.lastSeen, 120))
    if(delta > 0) n.onlineSeconds += delta
    n.wallet = wallet
    n.ts = ts
    n.lastSeen = ts
  }
  nodes.set(nodeId, n)
  return res.json({ ok: true })
})

app.get('/nodes', (req, res) => {
  const now = Math.floor(Date.now()/1000)
  const window = 24*3600
  const out = []
  for (const [nodeId, n] of nodes.entries()){
    const online = (now - n.ts) <= 300
    // approximate uptime: onlineSeconds / 24h window (cap at 100%)
    const uptimePct = Math.min(100, Math.round((n.onlineSeconds / window) * 1000) / 10)
    out.push({ nodeId, wallet: n.wallet, ts: n.ts, online, uptimePct })
  }
  res.json({ nodes: out })
})

const PORT = process.env.PORT || 8788
app.listen(PORT, () => console.log('Heartbeat API on :' + PORT))
