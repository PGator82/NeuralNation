import { expect } from "chai";
import { ethers } from "hardhat";

describe("Core NNN", function(){
  it("mints NNC, mints NID, stakes and earns", async function(){
    const [owner, alice] = await ethers.getSigners();

    const NNC = await ethers.getContractFactory("NeuralNubianCoin");
    const nnc = await NNC.deploy(owner.address, ethers.parseUnits("1000000",18), ethers.parseUnits("1000000",18));
    await nnc.waitForDeployment();

    const NID = await ethers.getContractFactory("NeuralID");
    const nid = await NID.deploy("ipfs://nid/");
    await nid.waitForDeployment();
    await (await nid.setIssuer(owner.address, true)).wait();

    const Staking = await ethers.getContractFactory("NNCStakingV2");
    const staking = await Staking.deploy(await nnc.getAddress(), await nid.getAddress(), ethers.parseUnits("1",18), 0, 0);
    await staking.waitForDeployment();

    // fund alice & staking
    await (await nnc.mint(alice.address, ethers.parseUnits("1000",18))).wait();
    await (await nnc.mint(await staking.getAddress(), ethers.parseUnits("1000",18))).wait();

    // mint NID to alice
    await (await nid.mint(alice.address, ethers.encodeBytes32String("alice"))).wait();
    expect(await nid.balanceOf(alice.address)).to.equal(1);

    // stake
    await (await nnc.connect(alice).approve(await staking.getAddress(), ethers.parseUnits("200",18))).wait();
    await (await staking.connect(alice).stake(ethers.parseUnits("200",18))).wait();

    // earn a bit
    await ethers.provider.send("evm_increaseTime", [10]);
    await ethers.provider.send("evm_mine", []);

    const earned = await staking.earned(alice.address);
    expect(earned).to.be.gt(0n);

    // claim
    await (await staking.connect(alice).claim()).wait();
    const bal = await nnc.balanceOf(alice.address);
    expect(bal).to.be.gt(0n);
  });
});
